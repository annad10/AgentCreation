# Course Match

## Project theory — draft for the team to review
Exchange students need to compare course syllabi before requesting credit recognition.
Course Match aims to reduce the time needed to prepare an evidence-based request.
It will compare a home-university syllabus with the Bocconi syllabi provided by the team.
Each suggested match will cite both sources and route uncertain cases to an advisor.
Success will be assessed against verified equivalences and manually checked citations.

## Current status
This is a working **starter**, not a completed AI application.
The homepage and `GET /health` work. Submitting the form displays an honest placeholder, without sending or storing the entered text.
AI calls, PDF parsing, retrieval, matching, numerical checks and `POST /match` remain unimplemented.
No API key is needed for this version. No real course PDFs or approved equivalence data are included.

## Start on your computer
Install Python 3.10 or later, extract the ZIP and open a terminal **inside `course-match`**.

```sh
python -m venv .venv
```

Activate on macOS/Linux (use `python3` instead of `python` if needed):

```sh
source .venv/bin/activate
```

On Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Then install and start:

```sh
python -m pip install -r requirements.txt
python -m uvicorn backend.main:app --reload --port 8000
```

Open http://127.0.0.1:8000 in your browser. Stop the server with Ctrl+C.
The health endpoint is http://127.0.0.1:8000/health and should return `{"ok":true}`.
Run tests in an activated terminal with `python -m pytest`.
Do not open index.html directly: start the server first so the stylesheet and script load.

## Upload to your empty GitHub repository
1. Extract the ZIP. Upload the **contents** of `course-match`, not the ZIP itself.
2. Include backend, frontend, data, tests, README.md, CLAUDE.md, NOTES.md and requirements.txt.
3. Also include hidden starter files: .gitignore, .env.example and .claude/settings.json. On a Mac use Command+Shift+Period to show hidden files.
4. Never upload .env, API keys or .venv. Browser uploads need a manual check; do not rely on .gitignore to filter selected files.
5. Commit with a message such as `Initial project skeleton`.

## Next implementation steps
1. Add course syllabi you are permitted to share to data/bocconi and verified test cases to data/approved.
2. Define the extracted course schema and how citations reference source passages.
3. Implement extraction and candidate retrieval.
4. Connect the selected model through backend/llm.py; define its actual prompts there or within the pipeline.
5. Implement judging, quote verification and well-defined numerical checks.
6. Add POST /match and connect the frontend to it.
7. Test both known matches and cases with insufficient evidence before claiming accuracy.

`CLAUDE.md` is a draft based on your notes. Review it yourselves, especially if your assignment requires it to be written by hand.
