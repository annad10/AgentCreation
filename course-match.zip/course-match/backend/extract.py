"""TODO: extract course topics, learning outcomes and credits from syllabus text.
Preserve document identifiers and source passages for citations.
PDF parsing is not implemented in this skeleton.
"""
