"""Future model gateway: only this module may import the model SDK.
No API call is implemented. Keep credentials server-side and out of logs.
"""

def call_model(*args, **kwargs):
    raise NotImplementedError("Model connection is not implemented yet.")
