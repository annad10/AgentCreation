"""TODO: verify quotes and calculate coverage and credit conversions in code.
Agree on a coverage definition and an authoritative credit-conversion rule first.
Missing conversion rules must not be guessed.
"""
