"""Starter server. No model calls or course matching yet."""
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

FRONTEND = Path(__file__).resolve().parents[1] / "frontend"
app = FastAPI(title="Course Match", version="0.1.0")
app.mount("/static", StaticFiles(directory=FRONTEND), name="static")

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/", include_in_schema=False)
def home():
    return FileResponse(FRONTEND / "index.html")
