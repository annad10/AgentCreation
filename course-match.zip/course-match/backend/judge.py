"""TODO: propose matches and critique them using evidence from both syllabi.
Weak evidence must lead to an 'ask your advisor' outcome.
"""
