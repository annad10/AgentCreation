"""TODO: retrieve candidate courses from data/bocconi only.
Preserve source references; never invent course details.
"""
