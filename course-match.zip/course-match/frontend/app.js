"use strict";
const form = document.querySelector("#course-form");
const result = document.querySelector("#result");
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const syllabus = document.querySelector("#syllabus").value.trim();
  if (!syllabus) {
    result.textContent = "Please paste some syllabus text first.";
    return;
  }
  result.textContent = "Form checked successfully. Your text has stayed in this browser; it has not been sent to an AI model. Course matching is not implemented yet.";
});
