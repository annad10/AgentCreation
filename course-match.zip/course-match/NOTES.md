# Decisions and current status

- Created a starter matching the supplied project structure: FastAPI and plain HTML/CSS/JavaScript.
- The page and /health are implemented; /match does not exist yet.
- The form deliberately shows a placeholder instead of fabricating course matches.
- No API key is required to run this starter; no model requests are made.
- No syllabus PDFs or approved equivalences were supplied as source data, so both data folders are empty.
- Use text input first; add PDF parsing as a separate feature.
- The .claude permissions file is a supplemental read restriction, not a complete security boundary. Never ask tools or shell commands to print secrets.
- requirements.txt uses compatible ranges; lock exact versions after the team agrees on its environment.
- Validation: Python compilation, JavaScript syntax, and form-handler checks passed. FastAPI/pytest integration tests could not run in the creation environment because dependencies were unavailable and installation failed. Run python -m pytest after installing requirements locally.
